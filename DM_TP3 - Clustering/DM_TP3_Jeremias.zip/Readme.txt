C�DIGO:

ej1a/b          ejercicios 1A y 1B
stability.R     ejercicio 2 y 3
gapStatistic.R  ejercicio 2 y 3
opcional.R      ejercicio 4

